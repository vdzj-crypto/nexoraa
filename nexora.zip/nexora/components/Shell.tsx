"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { Search, Bell, PanelRightClose, PanelRightOpen, Menu, X, ChevronDown, User, LogOut, Waves, CornerDownLeft } from "lucide-react";
import { NAV } from "@/lib/nav";
import { ToastProvider, useToast } from "./Toast";
import DigitalBackground from "./DigitalBackground";

function Logo({ small }: { small?: boolean }) {
  return (<div className="flex items-center gap-3">
    <svg width="34" height="34" viewBox="0 0 34 34" aria-hidden><rect width="34" height="34" rx="10" fill="#15181c" stroke="#d8b25e" strokeOpacity=".5"/>
      <path d="M9 25V9l16 16V9" fill="none" stroke="#34d399" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"/><circle cx="25" cy="9" r="2" fill="#d8b25e"/></svg>
    {!small && <span className="text-[19px] font-bold tracking-[.18em]" dir="ltr">NEXORA</span>}</div>);
}

function Palette({ open, onClose }: { open: boolean; onClose: () => void }) {
  const r = useRouter(); const [q, setQ] = useState(""); const [i, setI] = useState(0); const inp = useRef<HTMLInputElement>(null);
  const list = NAV.filter((n) => n.label.includes(q.trim()) || n.blurb.includes(q.trim()));
  useEffect(() => { if (open) { setQ(""); setI(0); setTimeout(() => inp.current?.focus(), 20); } }, [open]);
  if (!open) return null;
  const go = (s: string) => { r.push("/" + s); onClose(); };
  return (<div className="fixed inset-0 z-[60] grid place-items-start bg-black/60 p-4 pt-[14vh] backdrop-blur-sm" onMouseDown={onClose}>
    <div role="dialog" aria-modal aria-label="بحث وانتقال سريع" className="pop panel mx-auto w-full max-w-lg overflow-hidden shadow-2xl" onMouseDown={(e) => e.stopPropagation()}
      onKeyDown={(e) => { if (e.key === "Escape") onClose(); if (e.key === "ArrowDown") { e.preventDefault(); setI((x) => Math.min(x + 1, list.length - 1)); } if (e.key === "ArrowUp") { e.preventDefault(); setI((x) => Math.max(x - 1, 0)); } if (e.key === "Enter" && list[i]) go(list[i].slug); }}>
      <div className="flex items-center gap-3 border-b border-ink-700 px-4"><Search size={18} className="text-mute" />
        <input ref={inp} value={q} onChange={(e) => { setQ(e.target.value); setI(0); }} placeholder="انتقل إلى قسم…" className="h-14 w-full bg-transparent text-base outline-none placeholder:text-mute" /></div>
      <ul className="scroll max-h-72 overflow-auto p-2">
        {list.length === 0 && <li className="px-4 py-8 text-center text-sm text-mute">لا توجد أقسام مطابقة لـ «{q}». جرّب كلمة أقصر.</li>}
        {list.map((n, k) => (<li key={n.slug}><button onClick={() => go(n.slug)} onMouseEnter={() => setI(k)}
          className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-start text-sm ${k === i ? "bg-ink-800 text-gold" : ""}`}><n.icon size={18} />{n.label}
          {k === i && <CornerDownLeft size={14} className="ms-auto text-mute" />}</button></li>))}
      </ul></div></div>);
}

function Menu_({ label, icon, children }: { label: string; icon: React.ReactNode; children: (close: () => void) => React.ReactNode }) {
  const [o, setO] = useState(false); const ref = useRef<HTMLDivElement>(null);
  useEffect(() => { const f = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setO(false); }; const k = (e: KeyboardEvent) => e.key === "Escape" && setO(false);
    document.addEventListener("mousedown", f); document.addEventListener("keydown", k); return () => { document.removeEventListener("mousedown", f); document.removeEventListener("keydown", k); }; }, []);
  return (<div ref={ref} className="relative"><button aria-label={label} aria-expanded={o} aria-haspopup="menu" onClick={() => setO(!o)}
    className="grid h-10 min-w-10 place-items-center rounded-xl border border-ink-700 bg-ink-850 px-2 hover:border-gold-dim">{icon}</button>
    {o && <div role="menu" className="pop panel absolute end-0 top-12 z-50 w-72 p-2 shadow-2xl shadow-black/70">{children(() => setO(false))}</div>}</div>);
}

function Inner({ children }: { children: React.ReactNode }) {
  const path = usePathname(); const toast = useToast();
  const [collapsed, setCollapsed] = useState(false); const [drawer, setDrawer] = useState(false);
  const [motion, setMotion] = useState(true); const [pal, setPal] = useState(false); const [unread, setUnread] = useState(3);
  useEffect(() => { try { setCollapsed(localStorage.getItem("nx.collapsed") === "1"); setMotion(localStorage.getItem("nx.motion") !== "0"); } catch {} }, []);
  useEffect(() => { setDrawer(false); }, [path]);
  useEffect(() => { const k = (e: KeyboardEvent) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setPal(true); } }; window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k); }, []);
  const save = (k: string, v: string) => { try { localStorage.setItem(k, v); } catch {} };
  const active = (s: string) => (s === "" ? path === "/" : path.startsWith("/" + s));
  const nav = (mini: boolean) => (<nav aria-label="التنقل الرئيسي" className="scroll flex-1 space-y-1 overflow-y-auto px-3 py-2">
    {NAV.map((n) => (<Link key={n.slug} href={"/" + n.slug} title={mini ? n.label : undefined} aria-current={active(n.slug) ? "page" : undefined}
      className={`group relative flex h-11 items-center gap-3 rounded-xl px-3 text-[14px] transition-colors ${active(n.slug) ? "bg-ink-800 text-paper" : "text-mute hover:bg-ink-850 hover:text-paper"} ${mini ? "justify-center" : ""}`}>
      {active(n.slug) && <span className="absolute inset-y-2 end-0 w-[3px] rounded-full bg-gold" />}
      <n.icon size={19} className={active(n.slug) ? "text-gold" : ""} />{!mini && <span>{n.label}</span>}</Link>))}</nav>);
  return (<div className="min-h-screen">
    <DigitalBackground animate={motion} />
    <aside className={`fixed inset-y-0 end-0 z-30 hidden flex-col border-s border-ink-700 bg-ink-900/90 backdrop-blur transition-[width] duration-200 lg:flex ${collapsed ? "w-[76px]" : "w-64"}`}>
      <div className={`flex h-16 items-center ${collapsed ? "justify-center" : "px-5"}`}><Logo small={collapsed} /></div>{nav(collapsed)}
      <button onClick={() => { setCollapsed(!collapsed); save("nx.collapsed", collapsed ? "0" : "1"); }} aria-label={collapsed ? "توسيع القائمة" : "طي القائمة"}
        className="m-3 flex h-10 items-center justify-center gap-2 rounded-xl border border-ink-700 text-xs text-mute hover:text-paper">{collapsed ? <PanelRightOpen size={17} /> : <><PanelRightClose size={17} />طي القائمة</>}</button></aside>
    {drawer && <div className="fixed inset-0 z-40 lg:hidden"><div className="absolute inset-0 bg-black/70" onClick={() => setDrawer(false)} />
      <aside className="pop absolute inset-y-0 end-0 flex w-72 flex-col bg-ink-900"><div className="flex h-16 items-center justify-between px-5"><Logo />
        <button aria-label="إغلاق" onClick={() => setDrawer(false)}><X size={20} /></button></div>{nav(false)}</aside></div>}
    <div className={`relative z-10 transition-[padding] duration-200 ${collapsed ? "lg:pe-[76px]" : "lg:pe-64"}`}>
      <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-ink-700 bg-ink-950/80 px-4 backdrop-blur md:px-8">
        <button className="lg:hidden" aria-label="فتح القائمة" onClick={() => setDrawer(true)}><Menu size={22} /></button>
        <button onClick={() => setPal(true)} className="flex h-10 flex-1 items-center gap-3 rounded-xl border border-ink-700 bg-ink-850 px-3 text-sm text-mute hover:border-gold-dim md:max-w-md">
          <Search size={17} /><span className="flex-1 text-start">ابحث أو انتقل إلى قسم…</span><kbd className="hidden rounded border border-ink-600 px-1.5 text-[11px] md:block" dir="ltr">Ctrl K</kbd></button>
        <div className="ms-auto flex items-center gap-2">
          <button aria-pressed={motion} aria-label="الحركة الخلفية" title={motion ? "إيقاف حركة الخلفية" : "تشغيل حركة الخلفية"}
            onClick={() => { setMotion(!motion); save("nx.motion", motion ? "0" : "1"); toast("info", motion ? "تم إيقاف حركة الخلفية" : "تم تشغيل حركة الخلفية"); }}
            className={`grid h-10 w-10 place-items-center rounded-xl border border-ink-700 bg-ink-850 ${motion ? "text-em" : "text-mute"}`}><Waves size={18} /></button>
          <Menu_ label="الإشعارات" icon={<span className="relative"><Bell size={18} />{unread > 0 && <span className="absolute -end-1.5 -top-1.5 grid h-4 min-w-4 place-items-center rounded-full bg-gold px-1 text-[10px] font-bold text-ink-950">{unread}</span>}</span>}>
            {(close) => (<div><p className="px-3 py-2 text-xs text-mute">إشعارات تجريبية</p>
              {["اقترب موعد قسط السيارة", "ميزانية الطعام بلغت 85٪", "تم استيراد ملف المبيعات"].map((t) => <p key={t} className="rounded-lg px-3 py-2 text-sm">{t}</p>)}
              <button className="mt-1 w-full rounded-lg px-3 py-2 text-start text-sm text-gold hover:bg-ink-800" onClick={() => { setUnread(0); close(); toast("ok", "تم تعليم الإشعارات كمقروءة"); }}>تعليم الكل كمقروء</button></div>)}</Menu_>
          <Menu_ label="الملف الشخصي" icon={<span className="flex items-center gap-2"><span className="grid h-7 w-7 place-items-center rounded-full bg-gold/15 text-xs font-bold text-gold">ض</span><ChevronDown size={14} className="text-mute" /></span>}>
            {(close) => (<div><Link href="/settings" onClick={close} className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm hover:bg-ink-800"><User size={16} />الملف الشخصي</Link>
              <button onClick={() => { close(); toast("info", "تسجيل الدخول يحتاج إعداد Supabase — راجع README"); }} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm hover:bg-ink-800"><LogOut size={16} />تسجيل الخروج</button></div>)}</Menu_></div></header>
      <main className="px-4 py-6 md:px-8">{children}</main></div>
    <Palette open={pal} onClose={() => setPal(false)} /></div>);
}
export default function Shell({ children }: { children: React.ReactNode }) { return <ToastProvider><Inner>{children}</Inner></ToastProvider>; }
