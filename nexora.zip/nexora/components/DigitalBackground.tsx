"use client";
import { useEffect, useRef } from "react";
const GLYPHS = ["0","1","2","3","4","5","6","7","8","9","+","−","×","÷","=","%","Σ","π","∫","√","Δ","ر.س","f(x)","SUM","A1:B9"];
export default function DigitalBackground({ animate }: { animate: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current!, g = c.getContext("2d")!;
    let w = 0, h = 0, raf = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const resize = () => { w = c.clientWidth; h = c.clientHeight; c.width = w * dpr; c.height = h * dpr; g.setTransform(dpr, 0, 0, dpr, 0, 0); };
    resize(); window.addEventListener("resize", resize);
    const n = Math.min(34, Math.floor((window.innerWidth * window.innerHeight) / 38000));
    const ps = Array.from({ length: n }, () => ({ x: Math.random(), y: Math.random(), s: 11 + Math.random() * 14, v: 0.004 + Math.random() * 0.008,
      t: GLYPHS[Math.floor(Math.random() * GLYPHS.length)], a: 0.035 + Math.random() * 0.06, gold: Math.random() < 0.18 }));
    const draw = () => {
      g.clearRect(0, 0, w, h);
      for (const p of ps) {
        g.font = `${p.s}px ui-monospace, monospace`;
        g.fillStyle = p.gold ? `rgba(216,178,94,${p.a})` : `rgba(52,211,153,${p.a})`;
        g.fillText(p.t, p.x * w, p.y * h);
        if (animate) { p.y -= p.v / 60; if (p.y < -0.05) { p.y = 1.05; p.x = Math.random(); } }
      }
      if (animate) raf = requestAnimationFrame(draw);
    };
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce || !animate) draw(); else raf = requestAnimationFrame(draw);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, [animate]);
  return <canvas ref={ref} aria-hidden className="pointer-events-none fixed inset-0 h-full w-full" />;
}
