"use client";
import { createContext, useCallback, useContext, useState } from "react";
import { CheckCircle2, XCircle, Info } from "lucide-react";
type T = { id: number; kind: "ok" | "err" | "info"; msg: string };
const Ctx = createContext<(kind: T["kind"], msg: string) => void>(() => {});
export const useToast = () => useContext(Ctx);
export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<T[]>([]);
  const push = useCallback((kind: T["kind"], msg: string) => {
    const id = Date.now() + Math.random();
    setItems((s) => [...s.slice(-2), { id, kind, msg }]);
    setTimeout(() => setItems((s) => s.filter((x) => x.id !== id)), 3800);
  }, []);
  const Icon = { ok: CheckCircle2, err: XCircle, info: Info };
  const col = { ok: "text-em", err: "text-rose", info: "text-gold" };
  return (<Ctx.Provider value={push}>{children}
    <div aria-live="polite" className="fixed bottom-4 start-4 z-[70] flex flex-col gap-2">
      {items.map((t) => { const I = Icon[t.kind]; return (
        <div key={t.id} role="status" className="pop panel flex items-center gap-3 px-4 py-3 text-sm shadow-2xl shadow-black/60">
          <I size={18} className={col[t.kind]} />{t.msg}</div>); })}
    </div></Ctx.Provider>);
}
