import "./globals.css";
import type { Metadata, Viewport } from "next";
export const metadata: Metadata = { title: "NEXORA — حسابات أذكى من الجداول", description: "منصة جداول وحسابات مالية وإدارية" };
export const viewport: Viewport = { themeColor: "#0b0c0e", width: "device-width", initialScale: 1 };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="ar" dir="rtl"><head>
    <link rel="preconnect" href="https://fonts.googleapis.com" /><link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap" rel="stylesheet" />
  </head><body>{children}</body></html>);
}
