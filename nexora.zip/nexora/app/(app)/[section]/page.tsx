"use client";
import { use } from "react";
import { notFound } from "next/navigation";
import { Hammer } from "lucide-react";
import { NAV } from "@/lib/nav";
import { useToast } from "@/components/Toast";
export default function Section({ params }: { params: Promise<{ section: string }> }) {
  const { section } = use(params); const toast = useToast();
  const n = NAV.find((x) => x.slug === section && x.slug !== ""); if (!n) notFound();
  return (<div className="mx-auto max-w-3xl pt-10"><div className="panel grid place-items-center gap-4 px-6 py-16 text-center">
    <span className="grid h-14 w-14 place-items-center rounded-2xl bg-ink-800 text-gold"><n.icon size={26} /></span>
    <h1 className="text-2xl font-bold">{n.label}</h1><p className="max-w-sm text-sm text-mute">{n.blurb}</p>
    <p className="flex items-center gap-2 rounded-lg bg-gold/10 px-3 py-1.5 text-xs text-gold"><Hammer size={14} />هذا القسم لم يُنفَّذ بعد — الواجهة جاهزة للتنقل فقط.</p>
    {n.cta && <button onClick={() => toast("info", "سيتوفر في مرحلة التطوير القادمة")} className="h-11 rounded-xl bg-gold px-6 font-semibold text-ink-950">{n.cta}</button>}</div></div>);
}
