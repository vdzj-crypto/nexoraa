"use client";
import { useEffect, useState } from "react";
import { Area, AreaChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ArrowUpRight, ArrowDownRight, FilePlus2, Upload, Calculator, Receipt, FileSpreadsheet, RotateCw, X, Check, AlertTriangle, Inbox, FlaskConical } from "lucide-react";
import { alerts as A0, categories, files as F0, series, type FileRow } from "@/lib/demo";
import { useToast } from "@/components/Toast";

const fmt = (n: number) => n.toLocaleString("en-US");
type View = "ok" | "loading" | "empty" | "error";

function Stat({ label, value, delta, up, gold }: { label: string; value: number; delta: string; up: boolean; gold?: boolean }) {
  return (<div className="panel p-5"><p className="text-sm text-mute">{label}</p>
    <p className={`num mt-3 text-[30px] font-bold leading-none ${gold ? "text-gold" : "text-paper"}`}>{fmt(value)} <span className="text-sm font-medium text-mute">ر.س</span></p>
    <p className={`num mt-3 flex items-center gap-1 text-xs ${up ? "text-em" : "text-rose"}`}>{up ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}{delta} عن الشهر الماضي</p></div>);
}

export default function Dashboard() {
  const toast = useToast();
  const [range, setRange] = useState<6 | 12>(12);
  const [view, setView] = useState<View>("loading");
  const [files, setFiles] = useState<FileRow[]>(F0);
  const [alerts, setAlerts] = useState(A0);
  const [dlg, setDlg] = useState(false); const [name, setName] = useState(""); const [err, setErr] = useState("");
  useEffect(() => { if (view === "loading") { const t = setTimeout(() => setView("ok"), 900); return () => clearTimeout(t); } }, [view]);
  const data = series.slice(-range); const last = series[11], prev = series[10];
  const net = last.income - last.expense;
  const create = () => {
    if (name.trim().length < 2) { setErr("اكتب اسمًا من حرفين على الأقل."); return; }
    setFiles((f) => [{ id: Date.now(), name: name.trim(), kind: "جدول", when: "الآن" }, ...f]); setView("ok"); setDlg(false); setName(""); setErr(""); toast("ok", "تم إنشاء الجدول");
  };
  const actions = [
    { l: "جدول جديد", i: FilePlus2, f: () => setDlg(true) }, { l: "استيراد ملف", i: Upload, f: () => toast("info", "الاستيراد قيد التطوير في المرحلة التالية") },
    { l: "حاسبة عائد", i: Calculator, f: () => toast("info", "حاسبة العائد قيد التطوير") }, { l: "فاتورة جديدة", i: Receipt, f: () => toast("info", "الفواتير قيد التطوير") },
  ];
  return (<div className="mx-auto max-w-7xl space-y-6">
    <div className="flex flex-wrap items-center gap-3 rounded-xl border border-gold-dim/40 bg-gold/5 px-4 py-2.5 text-sm text-gold">
      <FlaskConical size={16} /><span>وضع العرض: كل الأرقام هنا بيانات تجريبية وليست حقيقية.</span>
      <label className="ms-auto flex items-center gap-2 text-xs text-mute">حالة قسم الملفات
        <select value={view} onChange={(e) => setView(e.target.value as View)} className="rounded-lg border border-ink-600 bg-ink-850 px-2 py-1 text-paper">
          <option value="ok">عادية</option><option value="loading">تحميل</option><option value="empty">فارغة</option><option value="error">خطأ</option></select></label></div>

    <section className="flex flex-wrap items-end justify-between gap-6 pt-2">
      <div><h1 className="text-lg text-mute">صافي أكتوبر</h1>
        <p className="num mt-2 text-[56px] font-bold leading-none text-em md:text-[76px]">+{fmt(net)}<span className="ms-3 text-xl font-medium text-mute">ر.س</span></p>
        <p className="mt-3 text-sm text-mute">دخل {fmt(last.income)} − مصروف {fmt(last.expense)}، وهو أعلى بمقدار {fmt(net - (prev.income - prev.expense))} من الشهر السابق.</p></div>
      <div className="flex flex-wrap gap-2">{actions.map((a) => (<button key={a.l} onClick={a.f} className="flex h-11 items-center gap-2 rounded-xl border border-ink-700 bg-ink-850 px-4 text-sm hover:border-gold-dim hover:text-gold"><a.i size={17} />{a.l}</button>))}</div></section>

    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <Stat label="الدخل الشهري" value={last.income} delta="+6.8٪" up />
      <Stat label="المصروفات" value={last.expense} delta="+1.5٪" up={false} />
      <Stat label="الادخار" value={24000} delta="+8.3٪" up gold />
      <Stat label="الالتزامات القادمة" value={2270} delta="−4.0٪" up /></div>

    <div className="grid gap-4 lg:grid-cols-3">
      <section className="panel p-5 lg:col-span-2" aria-label="الدخل مقابل المصروف">
        <div className="mb-4 flex items-center justify-between"><h2 className="font-semibold">الدخل مقابل المصروف</h2>
          <div role="group" aria-label="المدة" className="flex rounded-lg border border-ink-700 p-0.5 text-xs">{([6, 12] as const).map((r) => (
            <button key={r} aria-pressed={range === r} onClick={() => setRange(r)} className={`rounded-md px-3 py-1.5 ${range === r ? "bg-ink-700 text-paper" : "text-mute"}`}>{r} أشهر</button>))}</div></div>
        <div className="h-72 w-full" dir="ltr"><ResponsiveContainer><AreaChart data={data} margin={{ top: 8, right: 8, left: -8, bottom: 0 }}>
          <defs><linearGradient id="g1" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#34d399" stopOpacity=".35" /><stop offset="100%" stopColor="#34d399" stopOpacity="0" /></linearGradient></defs>
          <CartesianGrid stroke="#23272d" vertical={false} /><XAxis dataKey="month" reversed tick={{ fill: "#9097a1", fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis orientation="right" tick={{ fill: "#9097a1", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}k`} />
          <Tooltip contentStyle={{ background: "#15181c", border: "1px solid #272b31", borderRadius: 12, direction: "rtl", fontFamily: "inherit" }} formatter={(v, n) => [fmt(Number(v)) + " ر.س", n === "income" ? "الدخل" : "المصروف"]} />
          <Area type="monotone" dataKey="income" stroke="#34d399" strokeWidth={2.2} fill="url(#g1)" />
          <Area type="monotone" dataKey="expense" stroke="#d8b25e" strokeWidth={2} fill="none" strokeDasharray="5 4" /></AreaChart></ResponsiveContainer></div>
        <p className="mt-2 flex gap-5 text-xs text-mute"><span className="flex items-center gap-2"><i className="h-0.5 w-5 bg-em" />الدخل</span><span className="flex items-center gap-2"><i className="h-0.5 w-5 border-t-2 border-dashed border-gold" />المصروف</span></p></section>
      <section className="panel p-5" aria-label="توزيع المصروفات"><h2 className="mb-2 font-semibold">توزيع المصروفات</h2>
        <div className="h-44" dir="ltr"><ResponsiveContainer><PieChart><Pie data={categories} dataKey="value" innerRadius={48} outerRadius={72} paddingAngle={3} stroke="none">{categories.map((c) => <Cell key={c.name} fill={c.color} />)}</Pie>
          <Tooltip contentStyle={{ background: "#15181c", border: "1px solid #272b31", borderRadius: 12, direction: "rtl" }} formatter={(v) => fmt(Number(v)) + " ر.س"} /></PieChart></ResponsiveContainer></div>
        <ul className="mt-2 space-y-2 text-sm">{categories.map((c) => (<li key={c.name} className="flex items-center gap-2"><i className="h-2.5 w-2.5 rounded-full" style={{ background: c.color }} />{c.name}<span className="num ms-auto text-mute">{fmt(c.value)}</span></li>))}</ul></section></div>

    <div className="grid gap-4 lg:grid-cols-5">
      <section className="panel p-5 lg:col-span-3" aria-label="الملفات الأخيرة"><h2 className="mb-4 font-semibold">الجداول والملفات الأخيرة</h2>
        {view === "loading" && <div className="space-y-3">{[0, 1, 2, 3].map((k) => <div key={k} className="skel h-12" />)}</div>}
        {view === "error" && <div className="grid place-items-center gap-3 py-10 text-center"><AlertTriangle className="text-rose" /><p className="text-sm">تعذّر تحميل الملفات. تحقق من الاتصال ثم أعد المحاولة.</p>
          <button onClick={() => setView("loading")} className="flex items-center gap-2 rounded-lg border border-ink-600 px-4 py-2 text-sm hover:border-gold-dim"><RotateCw size={15} />إعادة المحاولة</button></div>}
        {view === "empty" && <div className="grid place-items-center gap-3 py-10 text-center"><Inbox className="text-mute" /><p className="text-sm text-mute">لا توجد ملفات بعد. أنشئ أول جدول لتبدأ.</p>
          <button onClick={() => setDlg(true)} className="rounded-lg bg-gold px-4 py-2 text-sm font-semibold text-ink-950">إنشاء جدول</button></div>}
        {view === "ok" && <ul className="divide-y divide-ink-700">{files.map((f) => (<li key={f.id}><button onClick={() => toast("info", `فتح «${f.name}» سيتوفر مع محرر الجداول`)} className="flex w-full items-center gap-3 py-3 text-start hover:text-gold">
          <span className="grid h-9 w-9 place-items-center rounded-lg bg-ink-800 text-em"><FileSpreadsheet size={17} /></span><span className="flex-1 text-sm">{f.name}</span>
          <span className="rounded-md bg-ink-800 px-2 py-0.5 text-xs text-mute">{f.kind}</span><span className="w-24 text-end text-xs text-mute">{f.when}</span></button></li>))}</ul>}</section>
      <section className="panel p-5 lg:col-span-2" aria-label="التنبيهات والمواعيد"><h2 className="mb-4 font-semibold">التنبيهات والمواعيد المالية</h2>
        {alerts.length === 0 ? <p className="py-8 text-center text-sm text-mute">لا توجد مواعيد قادمة. أنت على اطلاع بكل شيء.</p> :
          <ul className="space-y-2">{alerts.map((a) => (<li key={a.id} className="flex items-center gap-3 rounded-xl bg-ink-850 p-3">
            <i className={`h-9 w-1 rounded-full ${a.tone === "rose" ? "bg-rose" : a.tone === "em" ? "bg-em" : "bg-gold"}`} />
            <div className="flex-1"><p className="text-sm">{a.title}</p><p className="text-xs text-mute">{a.date}{a.amount && <> · <span className="num">{a.amount} ر.س</span></>}</p></div>
            <button aria-label={`تم: ${a.title}`} onClick={() => { setAlerts((s) => s.filter((x) => x.id !== a.id)); toast("ok", "تم تعليم التنبيه كمنجز"); }} className="grid h-8 w-8 place-items-center rounded-lg border border-ink-600 text-mute hover:border-em hover:text-em"><Check size={15} /></button></li>))}</ul>}</section></div>

    {dlg && <div className="fixed inset-0 z-[60] grid place-items-center bg-black/60 p-4 backdrop-blur-sm" onMouseDown={() => setDlg(false)}>
      <div role="dialog" aria-modal aria-labelledby="dt" className="pop panel w-full max-w-sm p-6" onMouseDown={(e) => e.stopPropagation()} onKeyDown={(e) => e.key === "Escape" && setDlg(false)}>
        <div className="flex items-center justify-between"><h2 id="dt" className="font-semibold">جدول جديد</h2><button aria-label="إغلاق" onClick={() => setDlg(false)}><X size={18} /></button></div>
        <label className="mt-5 block text-sm text-mute" htmlFor="nm">اسم الجدول</label>
        <input id="nm" autoFocus value={name} onChange={(e) => { setName(e.target.value); setErr(""); }} onKeyDown={(e) => e.key === "Enter" && create()} aria-invalid={!!err}
          className="mt-2 h-11 w-full rounded-xl border border-ink-600 bg-ink-850 px-3 outline-none focus:border-gold" placeholder="مثال: مصروفات نوفمبر" />
        {err && <p className="mt-2 text-xs text-rose" role="alert">{err}</p>}
        <div className="mt-6 flex gap-2"><button onClick={create} className="h-11 flex-1 rounded-xl bg-gold font-semibold text-ink-950">إنشاء الجدول</button>
          <button onClick={() => setDlg(false)} className="h-11 rounded-xl border border-ink-600 px-5">إلغاء</button></div></div></div>}
  </div>);
}
