import Link from "next/link";
export default function NF() { return <div className="grid min-h-screen place-items-center text-center"><div><p className="text-5xl font-bold text-gold">404</p><p className="mt-3 text-mute">هذه الصفحة غير موجودة.</p><Link href="/" className="mt-6 inline-block rounded-xl bg-gold px-5 py-2.5 font-semibold text-ink-950">العودة إلى لوحة التحكم</Link></div></div>; }
