// بيانات تجريبية فقط — لا تمثل أرقامًا حقيقية.
export const MONTHS = ["يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"];
const inc = [18200,19400,17800,21000,22500,21800,23900,24600,23100,25800,26400,28200];
const exp = [14100,15200,14800,15900,16700,17300,17100,18400,18900,19200,19800,20100];
export const series = MONTHS.map((m, i) => ({ month: m, income: inc[i], expense: exp[i] }));
export const categories = [
  { name: "السكن", value: 6200, color: "#d8b25e" }, { name: "الطعام", value: 3900, color: "#34d399" },
  { name: "النقل", value: 2600, color: "#6ee7b7" }, { name: "الأقساط", value: 4100, color: "#8f7637" }, { name: "أخرى", value: 3300, color: "#3a3f47" },
];
export type FileRow = { id: number; name: string; kind: string; when: string };
export const files: FileRow[] = [
  { id: 1, name: "ميزانية الأسرة 2026", kind: "جدول", when: "قبل ساعتين" },
  { id: 2, name: "كشف رواتب أكتوبر", kind: "رواتب", when: "أمس" },
  { id: 3, name: "مبيعات الربع الثالث.xlsx", kind: "مستورد", when: "قبل 3 أيام" },
  { id: 4, name: "جرد المستودع", kind: "مخزون", when: "الأسبوع الماضي" },
];
export const alerts = [
  { id: 1, title: "قسط السيارة", date: "1 نوفمبر", amount: "1,850", tone: "gold" },
  { id: 2, title: "فاتورة الكهرباء", date: "5 نوفمبر", amount: "420", tone: "gold" },
  { id: 3, title: "ميزانية الطعام بلغت 85٪", date: "هذا الشهر", amount: "", tone: "rose" },
  { id: 4, title: "دفعة الادخار الشهرية", date: "10 نوفمبر", amount: "2,000", tone: "em" },
];
