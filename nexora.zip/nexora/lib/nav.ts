import { LayoutDashboard, Table2, Wallet, PiggyBank, Landmark, TrendingUp, Receipt, Boxes, BarChart3, LayoutTemplate, FolderOpen, Settings, Sparkles, type LucideIcon } from "lucide-react";
export type NavItem = { slug: string; label: string; icon: LucideIcon; blurb: string; cta: string };
export const NAV: NavItem[] = [
  { slug: "", label: "لوحة التحكم", icon: LayoutDashboard, blurb: "نظرة شاملة على أرقامك.", cta: "" },
  { slug: "sheets", label: "الجداول الذكية", icon: Table2, blurb: "جداول بمعادلات تُحسب تلقائيًا.", cta: "إنشاء جدول" },
  { slug: "payroll", label: "الرواتب والبدلات", icon: Wallet, blurb: "الرواتب والبدلات والخصومات في مكان واحد.", cta: "إضافة موظف" },
  { slug: "budget", label: "الميزانيات والمصروفات", icon: PiggyBank, blurb: "حدّد ميزانية وتابع صرفك.", cta: "ميزانية جديدة" },
  { slug: "debts", label: "الديون والادخار", icon: Landmark, blurb: "الأقساط وأهداف الادخار.", cta: "إضافة التزام" },
  { slug: "invest", label: "الاستثمار والعوائد", icon: TrendingUp, blurb: "احسب العائد والنمو المتوقع.", cta: "حاسبة عائد" },
  { slug: "invoices", label: "الفواتير والمبيعات", icon: Receipt, blurb: "أصدر فواتير وتابع المبيعات.", cta: "فاتورة جديدة" },
  { slug: "inventory", label: "المخزون", icon: Boxes, blurb: "الأصناف والكميات وحدود إعادة الطلب.", cta: "إضافة صنف" },
  { slug: "reports", label: "التقارير", icon: BarChart3, blurb: "رسوم وتقارير قابلة للتصدير.", cta: "تقرير جديد" },
  { slug: "templates", label: "القوالب الجاهزة", icon: LayoutTemplate, blurb: "ابدأ من قالب جاهز.", cta: "استعراض القوالب" },
  { slug: "files", label: "مركز الملفات", icon: FolderOpen, blurb: "استيراد وتصدير Excel وCSV.", cta: "رفع ملف" },
  { slug: "assistant", label: "المساعد الذكي", icon: Sparkles, blurb: "تحليل بياناتك بالسؤال والجواب.", cta: "" },
  { slug: "settings", label: "الإعدادات", icon: Settings, blurb: "الملف الشخصي والتفضيلات.", cta: "" },
];
