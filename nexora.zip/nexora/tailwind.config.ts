import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: { extend: {
    colors: { ink:{950:"#0b0c0e",900:"#101215",850:"#15181c",800:"#1b1e23",700:"#272b31",600:"#3a3f47"},
      em:{DEFAULT:"#34d399",dim:"#1f8f6a"}, gold:{DEFAULT:"#d8b25e",dim:"#8f7637"}, mute:"#9097a1", paper:"#ece9e2", rose:"#f0716f" },
    fontFamily: { sans:['"IBM Plex Sans Arabic"','"Segoe UI"','Tahoma','system-ui','sans-serif'] },
  } }, plugins: [],
} satisfies Config;
